SMASHBOOK README.txt

	First of All, If you don't have node module you need to put the node module to both (fs,ws) OR install node module by type "npm install" in sec2_gr4_fe_src and sec2_gr4_ws_src

	Next, You need to do the following below (IF YOU DON'T USE DEFAULT), but if you want to default you can run 
		"npm start" in sec2_gr4_fe_src to run front_server.js and sec2_gr4_ws_src to run back_server.js, 

	The default will Ajarn's server as (203.159.93.114 team15 same in env file), but IF THERE ARE ERROR CAUSE OF SERVER you can run database on local and do more below, 
	if not you can open website :)

	Then, You open website at "localhost:3000"

===============================================================
	
	but if you want to edit you can do the following below VVVV (You can see the editable file in very below)

   First, sec2_gr4_src/sec2_gr4_fe_src (front server) =>
	1. Edit .env default is port 3000, but if you need to change port you can also edit :)
	{
		FRONT_PORT = 3000
	} 
	** If you change the front_server.js port or you want to run web service on other address you need to go

	
   Second, sec2_gr4_src/sec2_gr4_ws_src (back server) =>
	2. Edit .env default is on Ajarn's server, but if you need to run database on your local
		you need to change this .env to be your
	{
		DB_HOST="203.159.93.114"    >(can edit) Your Database host address
		DB_USER="team15"            >(can edit) Your Database user (Create your database previlege first!)
		DB_PASSWORD="WW31GV"        >(can edit) Your Database password (Create your database previlege first!)
		DB_DATABASE="team15"        >(can edit) Your Database name (default from in sec2_gr4_database.sql is "smashbook")

		BACK_PORT = 3070            >(can edit) Your back_server.js listening on PORT!
	}
	** If you change the back_server.js port or you want to run web service on other address you need to go

    Third, sec2_gr4_src/sec2_gr4_fe_src/static/apiAddress.js =>
	3. Edit apiAddress.js (This for store the URL of all APIs in front end that will call this address in every fetch function!)
	{
		const apiAddress = "http://localhost:3070"; (can edit) This is default, if web service are in another host you must
							               edit this url to use fetch api front client to web service
	}
	** If you change the apiAddress url or you want to make sure that url is the same of your back_server.js

=============================================================

List of Editable file (for reference) (PLEASE DO NOT EDIT OTHER FILES)
	1. .env in "\sec2_gr4_fe_src"
	2. .env in "\sec2_gr4_ws_src"
	3. apiAddress.js in "\sec2_gr4_fe_src\static"

===============================================================

Ours Member (Group 4)
Mr. Kritthanuch Peungpa 6588065 
Mr. Nakarin Phoorahong 6588070 
Mr. Chawanakorn Rittirut 6588084 
Mr. Punnut Sawetwannakul 6588142 
Mr. Bhurinat Kanchanasuwan 6588150 

==============================================================
THANK FOR README.TXT