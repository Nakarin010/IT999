function initMap() {
    var map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 13.797643069759067, lng: 100.3194038601584},
        zoom: 18,
        mapId: 'b99e982b777971a'
    });
}
