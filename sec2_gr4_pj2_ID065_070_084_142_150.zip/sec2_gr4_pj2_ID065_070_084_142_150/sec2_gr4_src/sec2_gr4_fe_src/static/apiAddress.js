function getApiAddress(){

    const apiAddress = "http://localhost:3070";   // Edit for your all of APIs address (Read more detail in README.TXT)

    return apiAddress;
}