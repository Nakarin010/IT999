function getApiAddress(){

    const apiAddress = "http://localhost:3070";   // Edit for your all of APIs address (Read more detail in README.TXT)
                                                // Use must fill in this form 
                                                // Example "http://localhost:3070" or http://123.456.789.10:3070 
                                                // If input wrong format, API will CAN NOT USE!

    return apiAddress;
}