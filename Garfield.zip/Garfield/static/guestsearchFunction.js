function searchGet() {
    const username = document.getElementById("username").value;
    const date = document.getElementById("date").value;
    const starttime = document.getElementById("starttime").value;
    const endtime = document.getElementById("endtime").value;
    const courtno = document.getElementById("courtno").value;

    fetch(`http://localhost:3070/slot`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            "username": username,
            "date": date ,
            "starttime": starttime,
            "endtime": endtime,
            "courtno": courtno
        })
    })
    .then(response => {
        if (response.ok) {
            response.json().then(data => {
                
                // DO THE LOOP INSIDE ME

            });
        } 
        else {
            
        }
    })
    .catch(error => {
        console.error('Error deleting user:', error);
    });

}
