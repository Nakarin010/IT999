function getApiAddress(){
    const apiAddress = "http://localhost:3070";
    return apiAddress;
}