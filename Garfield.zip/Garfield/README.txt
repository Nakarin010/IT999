SMASHBOOK README.txt

First of all, You need to edit 2 files
    1. static/apiAdress.js => It is the address of All of APIs in this web such as Update, Search apiAdress
        If you run this website on 'localhost:3070' NO NEED TO CHANGE.
    
    2. .env => It is use for database host and front_server.js , back_server.js runnion on ports
        2.1 DB_HOST => Input your database host (ex. localhost)
        2.2 DB_USER => Input your previlege of your database (you need to create your own previlege in your database and input in this)
        2.3 DB_PASSWORD =>
        2.4 DB_DATABASE => Database name (default: "smashbook") for database (if you run the attached sql file it will be 
            create a "smashbook" database that is default)

        2.5 FRONT_PORT => The port for front_server.js (router)
        2.6 BACK_PORT => The port for back_server.js (web service)