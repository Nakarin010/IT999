SMASHBOOK README.txt

First of All, If you don't have node module you need to install node module by type "npm install" in cmd that directory to your src path

Next, You need to edit 2 files
    1. static/apiAdress.js => It is the address of All of APIs in this web such as Update, Search apiAdress will call this function and return APIs 
        address for http request that use for every javascript fetching in client side
         ** If you run this website on default ('localhost:3070') NO NEED TO CHANGE.
    
    2. .env => It is use for database host and front_server.js , back_server.js runnion on ports
        2.1 DB_HOST => Input your database host (ex. localhost)
        2.2 DB_USER => Input your previlege of your database (you need to create your own previlege in your database and input in this)
        2.3 DB_PASSWORD => Same as 2.2
        2.4 DB_DATABASE => Database name (default: "smashbook") for database (if you run the attached ours sql file it will be 
            create a "smashbook" database that is default)

        2.5 FRONT_PORT => The port for front_server.js (router)
        2.6 BACK_PORT => The port for back_server.js  (web service)
            ** DEFAULT OF DATABASE in .env WAS SETTED as
            {
                DB_HOST="203.159.93.114"
                DB_USER="team15"
                DB_PASSWORD="WW31GV"
                DB_DATABASE="team15" 
            }
            ** Change it in .env then input your hostname, user, password, database of your database 

Final, Run the web server (node.js) by path to node directory then type 
    "node back_server.js" and "node front_server.js" to run the server!!!






Ours Member (Group 4)
Mr. Kritthanuch Peungpa 6588065 
Mr. Nakarin Phoorahong 6588070 
Mr. Chawanakorn Rittirut 6588084 
Mr. Punnut Sawetwannakul 6588142 
Mr. Bhurinat Kanchanasuwan 6588150 
